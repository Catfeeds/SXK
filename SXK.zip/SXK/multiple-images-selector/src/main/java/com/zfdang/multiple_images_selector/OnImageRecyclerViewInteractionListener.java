package com.zfdang.multiple_images_selector;


import com.zfdang.multiple_images_selector.models.ImageItem;

/**
 * Created by zfdang on 2016-4-12.
 */
public interface OnImageRecyclerViewInteractionListener {
    void onImageItemInteraction(ImageItem item);
}