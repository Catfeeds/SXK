package com.zfdang.multiple_images_selector;

import com.zfdang.multiple_images_selector.models.FolderItem;

/**
 * Created by zfdang on 2016-4-14.
 */
public interface OnFolderRecyclerViewInteractionListener {
    void onFolderItemInteraction(FolderItem item);
}
