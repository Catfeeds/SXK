package com.example.cfwifine.sxk.View;

/**
 * Created by gergun on 13/05/15.
 */
public interface OnBlurCompleteListener {

    public void onBlurComplete();
}
