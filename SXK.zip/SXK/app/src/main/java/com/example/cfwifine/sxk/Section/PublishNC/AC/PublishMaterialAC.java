package com.example.cfwifine.sxk.Section.PublishNC.AC;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.cfwifine.sxk.R;

public class PublishMaterialAC extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish_material_ac);
    }
}
